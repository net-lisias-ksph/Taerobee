# Taerobee
This Mod adds some early rocket engines, such as Aerobee and X-4 (V-2 sounding rocket).

@Beale(from forum) made this Mod, but he deleted it several days ago. I reposted it on Github.

If there is any same Mod has the same things in this Mod, I'll change this as soon as possible.

(As I know, some of modders are doing this, such as [ROEngine](https://github.com/KSP-RO/ROEngines) (by [Capkirk123](https://github.com/Capkirk123) from GitHub), [Small Steps - Sounding Rockets!](https://forum.kerbalspaceprogram.com/index.php?/topic/198573-wip-small-steps-sounding-rockets/) (by [Vals_Aerospace](https://forum.kerbalspaceprogram.com/index.php?/profile/208582-vals_aerospace/) from forum))

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br />This work is still licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0)</a>, isn't under a All Rights Reserved (because of [this](https://wiki.creativecommons.org/wiki/Considerations_for_licensors_and_licensees#Remember_the_license_may_not_be_revoked))
